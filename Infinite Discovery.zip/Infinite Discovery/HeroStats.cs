using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeroStats : MonoBehaviour
{
  public Text lvlTxt;
  public Text xpTxt;
  public Text poTxt;
  public int lvl;
  public int xp;
  public int po;
  public int armorResistance = 1;
  public int nextLevelXp = 20;

  void Start()
  {
    lvl = PlayerPrefs.GetInt("level", 1);
    xp = PlayerPrefs.GetInt("xp", 0);
    po = PlayerPrefs.GetInt("po", 0);
    nextLevelXp = PlayerPrefs.GetInt("nextLevelXp", 20);
    SetGUIVals();
  }

  public void LevelUp()
  {
    if (xp >= nextLevelXp)
    {
      xp -= nextLevelXp;
      nextLevelXp += 5;
      lvl++;
      LevelUp();
      int statsPoints = PlayerPrefs.GetInt("statsPoints", 0);
      PlayerPrefs.SetInt("statsPoints", statsPoints + 2);
    }
  }

  public void SetGUIVals()
  {
    lvlTxt.text = "Level " + lvl;
    xpTxt.text = "XP: " + xp + "/" + nextLevelXp;
    poTxt.text = po + " PO";
    SaveHeroStats();
  }

  public void SaveHeroStats()
  {
    PlayerPrefs.SetInt("level", lvl);
    PlayerPrefs.SetInt("xp", xp);
    PlayerPrefs.SetInt("po", po);
    PlayerPrefs.SetInt("nextLevelXp", nextLevelXp);
  }

  public void ImproveArmor()
  {
    if (po >= 100)
    {
      po -= 100;
      armorResistance++;
      SetGUIVals();
    }
  }
}
