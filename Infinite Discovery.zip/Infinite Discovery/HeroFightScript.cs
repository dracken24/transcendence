using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroFightScript : MonoBehaviour
{
  public int vie = 1;
  public int force = 2;

  public GameObject enemy;
  Vector3 initialPos;
  EnemyScript enemyScript;
  public bool canFight = true;
  public GameObject camFight;
  public GameObject baseEnemy;
  public AudioClip audioClip;

  void Start()
  {
    initialPos = transform.position;
    enemyScript = enemy.GetComponent<EnemyScript>();
  }

  public void Atk1()
  {
    if (canFight)
    {
      // iTween.MoveFrom(gameObject, enemy.transform.position, 1);
      StartCoroutine("PlayAtk");
      canFight = false;
    }
  }

  IEnumerator PlayAtk()
  {
    GetComponent<AudioSource>().PlayOneShot(audioClip);
    iTween.MoveTo(gameObject, enemy.transform.position, 0.4f);
    enemyScript.vie -= force;
    enemyScript.SetLifeBar();
    yield return new WaitForSeconds(0.45f);
    iTween.MoveTo(gameObject, initialPos, 0.8f);
    if (enemyScript.vie <= 0)
    {
      MobBehaviour mb = baseEnemy.GetComponent<MobBehaviour>();
      if (mb.loot != null)
      {
        mb.DropLoot();
      }
      enemy.SetActive(false);
      baseEnemy.SetActive(false);
      yield return new WaitForSeconds(0.5f);
      camFight.SetActive(false);
      HeroStats hs = GameObject.FindObjectOfType<HeroStats>().GetComponent<HeroStats>();
      hs.xp += 10;
      hs.LevelUp();
      hs.SetGUIVals();
    }
    enemyScript.AtkHero();
  }
}
