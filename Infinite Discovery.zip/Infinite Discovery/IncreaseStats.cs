using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IncreaseStats : MonoBehaviour
{
  public int statsPoints;
  public Text forceTxt;
  public Text magicTxt;
  public Text speedTxt;

  void Start()
  {
    SetTxt();
    RefreshStatsPoints();
  }

  public void RefreshStatsPoints()
  {
    statsPoints = PlayerPrefs.GetInt("statsPoints", 0);
  }

  public void IncreaseSelectedStat(string statName)
  {
    if (statsPoints > 0)
    {
      statsPoints--;
      PlayerPrefs.SetInt("statsPoints", statsPoints);
      // statName peut être "force", "magic" ou "speed"
      PlayerPrefs.SetInt(statName, PlayerPrefs.GetInt(statName, 1) + 1);
      SetTxt();
    }
  }

  public void SetTxt()
  {
    forceTxt.text = "Force: " + PlayerPrefs.GetInt("force", 1);
    magicTxt.text = "Magic: " + PlayerPrefs.GetInt("magic", 1);
    speedTxt.text = "Speed: " + PlayerPrefs.GetInt("speed", 1);
  }
}
