using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PnjSimpleDial : MonoBehaviour
{
  public string simpleDial;
}
