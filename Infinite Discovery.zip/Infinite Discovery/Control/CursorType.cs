namespace RPG.Control
{
    public enum CursorType
    {
        None,
        Movement,
        Combat,
        UI,
        Pickup,
        FullPickup,
        Dialogue,
        Shop
    }
}