using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestTaker : MonoBehaviour
{
  QuestGiver qg;
  HeroStats hs;

  void Start()
  {
    hs = GetComponent<HeroStats>();
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    if (other.gameObject.tag == "quest_giver")
    {
      if (qg == null)
      {
        qg = other.gameObject.GetComponent<QuestGiver>();
        int isQuestDone = PlayerPrefs.GetInt(qg.questName, 0);
        if (!qg.quest.isActive && isQuestDone == 0) // Quête non active
        {
          qg.questPanel.SetActive(true);
          qg.ShowObjAfterQuestTaken();
          qg.questInfos[0].text = qg.quest.title;
          qg.questInfos[1].text = qg.quest.desc;
          qg.questInfos[2].text = "XP:" + qg.quest.xp + " | Gold:" + qg.quest.gold;
        }
        else // Quête active
        {
          if (qg.quest.isCompleted && qg.po > 0) // Quête terminée
          {
            qg.HideObjAfterQuest();
            print("Récompense = xp:" + qg.xp + " | or:" + qg.po);
            GetComponent<HeroCharacterCollisions>().ShowDialCanvasTxt(qg.questCompletedMsg);
            hs.xp += qg.xp;
            hs.po += qg.po;
            qg.po = 0;
            qg.xp = 0;
            hs.LevelUp();
            hs.SetGUIVals();
            PlayerPrefs.SetInt(qg.questName, 1);
          }
        }
      }
    }
  }

  void OnTriggerExit2D(Collider2D other)
  {
    if (other.gameObject.tag == "quest_giver")
    {
      qg.questPanel.SetActive(false);
      qg = null;
      GetComponent<HeroCharacterCollisions>().HideDialCanvas();
    }
  }

  public void TakeQuest()
  {
    qg.quest.isActive = true;
    qg.questPanel.SetActive(false);
  }
}
