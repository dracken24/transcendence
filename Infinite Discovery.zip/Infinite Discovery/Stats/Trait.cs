namespace RPG.Stats
{
    public enum Trait
    {
        Strength,
        Dexterity,
        Constitution,
        Intelligence,
        Charisma
    }
}