using GameDevTV.Inventories;
using UnityEngine;

namespace RPG.Inventories
{
    [CreateAssetMenu(fileName = "Currency Item", menuName = "Currency", order = 0)]
    public class CurrencyItem : InventoryItem
    {
    }
}

