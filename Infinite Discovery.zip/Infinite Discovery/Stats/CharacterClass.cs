namespace RPG.Stats
{
    public enum CharacterClass
    {
        Player,
        Grunt,
        Mage,
        Archer,
        Heavy
    }
}